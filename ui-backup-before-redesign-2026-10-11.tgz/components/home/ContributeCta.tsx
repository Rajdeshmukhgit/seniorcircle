import { PenLine } from "lucide-react";
import { ButtonLink } from "@/components/ui/Button";

export function ContributeCta() {
  return (
    <section id="contribute" className="border-t border-line">
      <div className="container-site py-14">
        <div className="flex flex-col items-start justify-between gap-6 rounded-card bg-[#E4E0FB] px-[22px] py-8 dark:bg-[#CDC6F7]/10 sm:px-9 md:flex-row md:items-center">
          <div className="max-w-xl">
            <h2 className="font-display text-[26px] font-extrabold leading-[1.1] tracking-[-0.04em] text-[#241E5C] dark:text-ink sm:text-[30px]">
              Been through it already?
            </h2>
            <p className="mt-2 text-[15.5px] leading-relaxed text-[#3D3780] dark:text-soft">
              Your experience could help the next student prepare better.
            </p>
          </div>
          <ButtonLink
            href="/experiences/new"
            size="lg"
            variant="primary"
            className="h-11 gap-2 bg-[#241E5C] text-[14.5px] dark:bg-primary"
          >
            Share Your Experience
            <PenLine className="h-4 w-4" aria-hidden />
          </ButtonLink>
        </div>
      </div>
    </section>
  );
}
