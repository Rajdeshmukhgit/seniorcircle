import Link from "next/link";

interface SectionHeadingProps {
  title: string;
  subtitle: string;
  link?: { href: string; label: string };
}

export function SectionHeading({ title, subtitle, link }: SectionHeadingProps) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-5">
      <div className="max-w-2xl">
        <h2 className="heading-section">{title}</h2>
        <p className="mt-2.5 text-[15.5px] leading-relaxed text-soft">{subtitle}</p>
      </div>
      {link && (
        <Link href={link.href} className="shrink-0 whitespace-nowrap text-[14.5px] font-bold text-primary-text transition hover:opacity-80">
          {link.label} →
        </Link>
      )}
    </div>
  );
}
