import { Check } from "lucide-react";

interface NoteProps {
  year: string;
  title: string;
  lines: string[];
  tone: string;
  className: string;
}

function Note({ year, title, lines, tone, className }: NoteProps) {
  return (
    <div className={`absolute w-[250px] rounded-[16px] border border-line bg-card p-4 shadow-[0_10px_30px_rgba(20,22,28,0.08)] ${className}`}>
      <div className="flex items-center justify-between">
        <span className="meta-mono">Batch {year}</span>
        <span className={`h-2.5 w-2.5 rounded-full ${tone}`} />
      </div>
      <div className="mt-2.5 font-display text-[15px] font-bold leading-tight tracking-[-0.02em] text-ink">{title}</div>
      <ul className="mt-2 space-y-1 text-[12.5px] leading-snug text-soft">
        {lines.map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
    </div>
  );
}

/** Decorative: three batches' notes, stacked and handed down. */
export function HeroArt() {
  return (
    <div aria-hidden className="relative mx-auto h-[390px] w-full max-w-[440px] select-none">
      <div className="absolute inset-x-5 bottom-6 top-10 -rotate-3 rounded-[32px] bg-[#E4E0FB] dark:bg-[#CDC6F7]/10" />
      <Note
        year="2024"
        title="GATE CSE, AIR 412"
        lines={["Previous-year questions, twice", "A notebook of mistakes"]}
        tone="bg-[#F0B25A]"
        className="left-0 top-2 -rotate-[5deg]"
      />
      <Note
        year="2025"
        title="AWS Solutions Architect"
        lines={["Six weeks of evenings", "Build it, then break it"]}
        tone="bg-[#F08A6C]"
        className="right-0 top-[118px] rotate-[4deg]"
      />
      <Note
        year="2027"
        title="Barclays, Software Engineer"
        lines={["Online test, technical, HR", "Know one project end to end"]}
        tone="bg-[#8E82E8]"
        className="bottom-3 left-6 -rotate-[1.5deg]"
      />
      <div className="absolute bottom-0 right-1 flex items-center gap-2 rounded-full border border-line bg-card py-1.5 pl-1.5 pr-3.5 text-[12.5px] font-semibold text-strong shadow-[0_8px_24px_rgba(20,22,28,0.08)]">
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#D9F0E3] text-[#0C3A26]">
          <Check className="h-3.5 w-3.5" />
        </span>
        Connect request accepted
      </div>
    </div>
  );
}
