import { ArrowRight, BadgeCheck, GraduationCap, PenLine, ShieldCheck, TrendingUp, type LucideIcon } from "lucide-react";
import { ButtonLink } from "@/components/ui/Button";
import { SITE_TAGLINE } from "@/lib/constants/site";
import { HeroArt } from "./HeroArt";

const points: { icon: LucideIcon; label: string; bg: string; fg: string }[] = [
  { icon: ShieldCheck, label: "Real Experiences", bg: "#CDC6F7", fg: "#241E5C" },
  { icon: BadgeCheck, label: "Verified Seniors & Alumni", bg: "#BCE7CF", fg: "#0C3A26" },
  { icon: TrendingUp, label: "Placement Insights", bg: "#FFD9A8", fg: "#5A3A0B" },
  { icon: GraduationCap, label: "Exam Guidance", bg: "#FFD3C7", fg: "#7A2A12" },
];

export function Hero() {
  return (
    <section id="hero">
      <div className="container-site grid items-center gap-10 pb-14 pt-28 sm:pt-32 lg:grid-cols-[1.4fr_1fr] lg:pb-16">
        <div className="max-w-[640px]">
          <h1 className="font-display text-[30px] font-extrabold leading-[1.05] tracking-[-0.045em] text-ink min-[420px]:text-[36px] sm:text-5xl lg:text-[40px] xl:text-[46px]">
            Learn From Experience.
            <br />
            <span className="text-primary-text">Move Forward</span> Confidently.
          </h1>
          <p className="mt-4 max-w-[450px] text-[17px] leading-[1.55] text-soft">{SITE_TAGLINE}</p>

          <div className="mt-6 flex flex-wrap items-center gap-2.5">
            <ButtonLink href="/feed" variant="primary" size="lg">
              Explore Experiences
              <ArrowRight className="h-[18px] w-[18px]" aria-hidden />
            </ButtonLink>
            <ButtonLink href="/experiences/new" variant="invert" size="lg" className="gap-2">
              Share Your Experience
              <PenLine className="h-4 w-4" aria-hidden />
            </ButtonLink>
          </div>

          <ul className="mt-6 flex flex-wrap items-center gap-x-[26px] gap-y-3">
            {points.map(({ icon: Icon, label, bg, fg }) => (
              <li key={label} className="flex items-center gap-2.5">
                <span
                  className="flex h-8 w-8 items-center justify-center rounded-[10px]"
                  style={{ backgroundColor: bg, color: fg }}
                >
                  <Icon className="h-[17px] w-[17px]" aria-hidden />
                </span>
                <span className="text-[14.5px] font-semibold text-strong">{label}</span>
              </li>
            ))}
          </ul>
        </div>

        <HeroArt />
      </div>
    </section>
  );
}
