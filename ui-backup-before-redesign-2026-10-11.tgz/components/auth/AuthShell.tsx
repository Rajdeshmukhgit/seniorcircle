import type { ReactNode } from "react";

interface AuthShellProps {
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}

/** The centred card every sign-in, sign-up and status screen sits in. */
export function AuthShell({ title, subtitle, children, footer, wide }: AuthShellProps) {
  return (
    <div className={`mx-auto w-full px-4 pb-16 pt-28 sm:pt-32 ${wide ? "max-w-[520px]" : "max-w-[440px]"}`}>
      <div className="rounded-card border border-line bg-card p-[22px] sm:p-8">
        <h1 className="font-display text-[26px] font-extrabold leading-[1.15] tracking-[-0.035em] text-ink">{title}</h1>
        {subtitle && <p className="mt-2 text-[14.5px] leading-relaxed text-soft">{subtitle}</p>}
        <div className="mt-6">{children}</div>
      </div>
      {footer && <div className="mt-5 text-center text-[14px] text-soft">{footer}</div>}
    </div>
  );
}

export const authLink = "font-semibold text-primary-text hover:underline";
