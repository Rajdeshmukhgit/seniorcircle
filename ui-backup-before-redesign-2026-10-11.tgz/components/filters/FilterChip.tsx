import Link from "next/link";
import { cn } from "@/lib/utils";

interface FilterChipProps {
  href: string;
  children: React.ReactNode;
  active?: boolean;
}

/** A pill that links to the feed with one filter applied. */
export function FilterChip({ href, children, active }: FilterChipProps) {
  return (
    <Link
      href={href}
      aria-current={active ? "true" : undefined}
      className={cn(
        "inline-flex rounded-full border px-3.5 py-[7px] text-[13.5px] font-medium leading-[1.7] transition",
        active
          ? "border-primary bg-primary text-white"
          : "border-line bg-chip text-soft hover:border-faint hover:text-ink",
      )}
    >
      {children}
    </Link>
  );
}
