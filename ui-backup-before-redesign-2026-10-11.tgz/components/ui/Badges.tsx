import { BadgeCheck, Clock3, ShieldAlert } from "lucide-react";
import { CATEGORY_LABEL, ROLE_LABEL } from "@/lib/constants/options";
import { cn } from "@/lib/utils";
import type { Category, Role, VerificationStatus } from "@/types";

const pill = "inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-1 text-[11px] font-bold leading-none";

// One tint per kind of experience, shared by cards, filters and the detail page.
const categoryTone: Record<Category, string> = {
  interview: "bg-[#E4E0FB] text-[#241E5C] dark:bg-[#CDC6F7]/15 dark:text-[#CDC6F7]",
  internship: "bg-[#D9F0E3] text-[#0C3A26] dark:bg-[#BCE7CF]/15 dark:text-[#BCE7CF]",
  exam: "bg-[#FFE7C7] text-[#5A3A0B] dark:bg-[#FFD9A8]/15 dark:text-[#FFD9A8]",
  certification: "bg-[#FFE0D7] text-[#7A2A12] dark:bg-[#FFD3C7]/15 dark:text-[#FFD3C7]",
};

export function CategoryBadge({ category, className }: { category: Category; className?: string }) {
  return <span className={cn(pill, categoryTone[category], className)}>{CATEGORY_LABEL[category]}</span>;
}

/** "Senior", "Alumni" and so on, next to an author's name. */
export function AuthorBadge({ role, className }: { role: Role; className?: string }) {
  return (
    <span className={cn("inline-flex shrink-0 items-center rounded-md bg-tint px-1.5 py-0.5 text-[11px] font-semibold leading-none text-soft", className)}>
      {ROLE_LABEL[role]}
    </span>
  );
}

/** Shown for alumni only. Students are verified by their college email. */
export function VerifiedBadge({ status, className }: { status: VerificationStatus; className?: string }) {
  if (status === "verified") {
    return (
      <span className={cn("inline-flex items-center gap-1 text-[12.5px] font-semibold text-success", className)}>
        <BadgeCheck className="h-3.5 w-3.5" aria-hidden />
        Verified alumni
      </span>
    );
  }
  if (status === "pending") {
    return (
      <span className={cn("inline-flex items-center gap-1 text-[12.5px] font-semibold text-soft", className)}>
        <Clock3 className="h-3.5 w-3.5" aria-hidden />
        Verification pending
      </span>
    );
  }
  if (status === "rejected") {
    return (
      <span className={cn("inline-flex items-center gap-1 text-[12.5px] font-semibold text-danger", className)}>
        <ShieldAlert className="h-3.5 w-3.5" aria-hidden />
        Not verified
      </span>
    );
  }
  return null;
}

export function StatusPill({ tone, children }: { tone: "neutral" | "success" | "danger"; children: React.ReactNode }) {
  return (
    <span
      className={cn(
        pill,
        "bg-tint",
        tone === "success" && "text-success",
        tone === "danger" && "text-danger",
        tone === "neutral" && "text-soft",
      )}
    >
      {children}
    </span>
  );
}
