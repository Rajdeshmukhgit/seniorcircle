import Link from "next/link";
import type { ButtonHTMLAttributes, ComponentProps } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "invert" | "solid" | "outline" | "ghost" | "danger";
type Size = "lg" | "md" | "sm";

const base =
  "inline-flex shrink-0 items-center justify-center whitespace-nowrap font-semibold transition active:scale-[0.98] disabled:pointer-events-none disabled:opacity-60";

const variants: Record<Variant, string> = {
  // Pill buttons used for the main call to action on a page.
  primary: "rounded-full bg-primary text-white hover:opacity-90",
  invert: "rounded-full bg-invert text-invert-ink hover:opacity-90",
  // Squarer buttons used in the navbar, forms and toolbars.
  solid: "rounded-lg bg-primary font-bold text-white shadow-sm hover:bg-primary-hover",
  outline: "rounded-xl border border-line bg-card font-bold text-soft hover:border-faint hover:text-ink",
  ghost: "rounded-lg text-soft hover:bg-tint hover:text-ink",
  danger: "rounded-xl border border-line bg-card font-bold text-danger hover:border-danger",
};

const sizes: Record<Size, string> = {
  lg: "h-[46px] gap-2.5 px-[22px] text-[15.5px]",
  md: "h-10 gap-2 px-4 text-sm",
  sm: "h-8 gap-1.5 px-3 text-[13px]",
};

export function buttonClass(variant: Variant = "solid", size: Size = "md", className?: string) {
  return cn(base, variants[variant], sizes[size], className);
}

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export function Button({ variant, size, className, type = "button", ...props }: ButtonProps) {
  return <button suppressHydrationWarning type={type} className={buttonClass(variant, size, className)} {...props} />;
}

interface ButtonLinkProps extends ComponentProps<typeof Link> {
  variant?: Variant;
  size?: Size;
}

export function ButtonLink({ variant, size, className, ...props }: ButtonLinkProps) {
  return <Link className={buttonClass(variant, size, className)} {...props} />;
}
