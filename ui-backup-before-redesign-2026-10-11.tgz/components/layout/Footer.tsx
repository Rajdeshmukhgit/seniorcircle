import { Mail, MapPin } from "lucide-react";
import Link from "next/link";
import { COLLEGE_NAME, CONTACT_EMAIL, SITE_MISSION, SITE_NAME } from "@/lib/constants/site";
import { LogoMark, Wordmark } from "./Logo";

const quickLinks = [
  { href: "/feed", label: "Experiences" },
  { href: "/trending", label: "Trending" },
  { href: "/experiences/new", label: "Share Experience" },
  { href: "/about#help", label: "Help" },
  { href: "/about", label: "About" },
];

const communityLinks = [
  { href: "/auth/signup", label: "Join as a student" },
  { href: "/auth/signup?type=alumni", label: "Join as alumni" },
  { href: "/about#guidelines", label: "Community guidelines" },
  { href: "/connections", label: "Your connections" },
];

const heading = "text-sm font-bold uppercase tracking-widest text-ink";
const link = "text-soft transition-colors hover:text-primary-text";

export function Footer() {
  return (
    <footer className="border-t border-line bg-footer">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:grid-cols-12">
          <div className="space-y-5 lg:col-span-4">
            <Link href="/" className="flex items-center gap-2.5 font-bold tracking-tight text-ink">
              <LogoMark size={36} />
              <Wordmark className="text-xl" />
            </Link>
            <p className="max-w-sm text-[15px] leading-relaxed text-soft">{SITE_MISSION}</p>
          </div>

          <div className="space-y-5 lg:col-span-2 lg:ml-auto">
            <h3 className={heading}>Quick Links</h3>
            <ul className="space-y-3.5 text-[15px] font-medium">
              {quickLinks.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className={link}>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-5 lg:col-span-3 lg:ml-auto">
            <h3 className={heading}>Community</h3>
            <ul className="space-y-3.5 text-[15px] font-medium">
              {communityLinks.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className={link}>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-5 lg:col-span-3">
            <h3 className={heading}>Contact</h3>
            <div className="space-y-4 text-[15px] font-medium text-soft">
              <div className="flex items-start gap-3.5">
                <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary-text">
                  <MapPin className="h-4 w-4" aria-hidden />
                </span>
                <span className="leading-relaxed">
                  {COLLEGE_NAME} campus
                  <br />
                  Student coordinator desk
                </span>
              </div>
              <a href={`mailto:${CONTACT_EMAIL}`} className="flex items-center gap-3.5 transition-colors hover:text-ink">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary-text">
                  <Mail className="h-4 w-4" aria-hidden />
                </span>
                <span className="break-all">{CONTACT_EMAIL}</span>
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-2 border-t border-hairline pt-6 text-[13.5px] text-faint sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {SITE_NAME}. For the {COLLEGE_NAME} student community.
          </p>
          <p>Built by students as a PBL III project.</p>
        </div>
      </div>
    </footer>
  );
}
