"use client";

import { Menu, X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { ButtonLink } from "@/components/ui/Button";
import { signOut } from "@/lib/actions/auth";
import { NAV_LINKS } from "@/lib/constants/site";
import { cn } from "@/lib/utils";
import { Logo } from "./Logo";
import { ThemeToggle } from "./ThemeToggle";
import { UserMenu } from "./UserMenu";
import type { Role } from "@/types";

interface NavbarShellProps {
  user: { name: string; role: Role; isAdmin: boolean; canPost: boolean } | null;
  /** The notification bell, rendered on the server with the unread count. */
  bell: ReactNode;
}

export function NavbarShell({ user, bell }: NavbarShellProps) {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the mobile menu after navigating.
  useEffect(() => setMenuOpen(false), [pathname]);

  const isActive = (href: string) => (href === "/" ? pathname === "/" : !href.includes("#") && pathname.startsWith(href));

  return (
    <header
      className={cn(
        "fixed top-0 z-50 w-full border-b transition-colors duration-200",
        scrolled || menuOpen ? "nav-solid border-line" : "border-transparent",
      )}
    >
      <div className="relative mx-auto flex w-full items-center justify-between gap-2 px-4 py-3 sm:px-6 lg:grid lg:grid-cols-[1fr_auto_1fr] lg:gap-4 xl:px-8 2xl:max-w-[1520px]">
        <Logo />

        <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              aria-current={isActive(link.href) ? "page" : undefined}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm font-medium transition-colors hover:bg-tint hover:text-ink",
                isActive(link.href) ? "text-ink" : "text-soft",
              )}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex lg:justify-self-end xl:gap-3">
          <ThemeToggle />
          {user ? (
            <>
              {bell}
              {user.canPost && (
                <ButtonLink href="/experiences/new" variant="solid">
                  Write Experience
                </ButtonLink>
              )}
              <UserMenu name={user.name} role={user.role} isAdmin={user.isAdmin} />
            </>
          ) : (
            <>
              <ButtonLink href="/auth/login" variant="outline">
                Sign In
              </ButtonLink>
              <ButtonLink href="/auth/signup" variant="solid">
                Join Community
              </ButtonLink>
            </>
          )}
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <ThemeToggle />
          {user && bell}
          <button suppressHydrationWarning
            type="button"
            onClick={() => setMenuOpen((value) => !value)}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-line bg-card text-soft shadow-sm transition hover:text-ink active:scale-95"
          >
            {menuOpen ? <X className="h-[18px] w-[18px]" aria-hidden /> : <Menu className="h-[18px] w-[18px]" aria-hidden />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <div id="mobile-menu" className="border-t border-line px-4 pb-5 pt-3 sm:px-6 lg:hidden">
          <nav aria-label="Mobile" className="flex flex-col">
            {NAV_LINKS.map((link) => (
              <Link key={link.href} href={link.href} className="rounded-lg px-2 py-2.5 text-[15px] font-semibold text-strong hover:bg-tint">
                {link.label}
              </Link>
            ))}
            {user && (
              <>
                <Link href="/profile" className="rounded-lg px-2 py-2.5 text-[15px] font-semibold text-strong hover:bg-tint">
                  Profile
                </Link>
                <Link href="/connections" className="rounded-lg px-2 py-2.5 text-[15px] font-semibold text-strong hover:bg-tint">
                  Connections
                </Link>
                {user.isAdmin && (
                  <Link href="/admin" className="rounded-lg px-2 py-2.5 text-[15px] font-semibold text-strong hover:bg-tint">
                    Admin Dashboard
                  </Link>
                )}
              </>
            )}
          </nav>
          <div className="mt-3 flex flex-col gap-2 border-t border-hairline pt-4">
            {user ? (
              <>
                {user.canPost && (
                  <ButtonLink href="/experiences/new" variant="solid" className="w-full">
                    Write Experience
                  </ButtonLink>
                )}
                <form action={signOut}>
                  <button suppressHydrationWarning type="submit" className="h-10 w-full rounded-xl border border-line bg-card text-sm font-bold text-soft">
                    Sign out
                  </button>
                </form>
              </>
            ) : (
              <>
                <ButtonLink href="/auth/signup" variant="solid" className="w-full">
                  Join Community
                </ButtonLink>
                <ButtonLink href="/auth/login" variant="outline" className="w-full">
                  Sign In
                </ButtonLink>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
