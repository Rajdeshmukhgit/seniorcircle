import { FlaskConical } from "lucide-react";
import { isDemoMode } from "@/lib/config";

/** Tells visitors the data is mock data. Disappears once Supabase is connected. */
export function DemoBanner() {
  if (!isDemoMode) return null;
  return (
    <div className="border-t border-line bg-muted">
      <p className="container-site flex items-start gap-2.5 py-3 text-[13px] leading-snug text-soft">
        <FlaskConical className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
        Demo mode: this site is running on sample data that resets when the server restarts. Add Supabase keys to
        .env.local to use a real database.
      </p>
    </div>
  );
}
